/**
 * AI Image Generation Metabox JavaScript
 */
(function($) {
    'use strict';

    var ImageMetabox = {
        /**
         * Initialize
         */
        init: function() {
            this.bindEvents();
        },

        /**
         * Bind event handlers
         */
        bindEvents: function() {
            $(document).on('click', '#aicr-generate-images', this.handleGenerate.bind(this));
            $(document).on('click', '#aicr-remove-images', this.handleRemove.bind(this));
        },

        /**
         * Handle generate button click
         */
        handleGenerate: function(e) {
            e.preventDefault();

            var self = this;
            var $button = $('#aicr-generate-images');
            var postId = $('#aicr-post-id').val();

            // Get post content from editor
            var content = this.getPostContent();

            if (!content || content.trim().length < 100) {
                alert(aicr_image.strings.no_content);
                return;
            }

            // Check if already generated
            if ($('.aicr-status-success').length > 0) {
                if (!confirm(aicr_image.strings.confirm_regenerate)) {
                    return;
                }
            }

            // Get options
            var options = {
                count: $('#aicr-image-count').val(),
                style: $('#aicr-image-style').val(),
                ratio: $('#aicr-image-ratio').val(),
                instructions: $('#aicr-image-instructions').val()
            };

            // Disable button and show progress
            $button.prop('disabled', true).html('<span class="aicr-spinner"></span> ' + aicr_image.strings.generating);
            this.showProgress(0, aicr_image.strings.generating);

            // Make AJAX request
            $.ajax({
                url: aicr_image.ajax_url,
                type: 'POST',
                data: {
                    action: 'aicr_generate_images',
                    nonce: aicr_image.nonce,
                    post_id: postId,
                    count: options.count,
                    style: options.style,
                    ratio: options.ratio,
                    instructions: options.instructions
                },
                success: function(response) {
                    if (response.success) {
                        self.showResult('success', response.data.message);
                        self.updateStatus(response.data);

                        // Simulate progress completion
                        self.showProgress(100, aicr_image.strings.success);

                        // Reload page to show updated content
                        setTimeout(function() {
                            window.location.reload();
                        }, 1500);
                    } else {
                        self.showResult('error', response.data || aicr_image.strings.error);
                        self.hideProgress();
                    }
                },
                error: function(xhr, status, error) {
                    self.showResult('error', aicr_image.strings.error + ': ' + error);
                    self.hideProgress();
                },
                complete: function() {
                    $button.prop('disabled', false).html('<span class="dashicons dashicons-format-image"></span> ' + '이미지 생성');
                }
            });

            // Simulate progress during generation
            this.simulateProgress();
        },

        /**
         * Handle remove button click
         */
        handleRemove: function(e) {
            e.preventDefault();

            if (!confirm('생성된 AI 이미지를 모두 제거하시겠습니까?')) {
                return;
            }

            var self = this;
            var $button = $('#aicr-remove-images');
            var postId = $('#aicr-post-id').val();

            $button.prop('disabled', true).text('제거 중...');

            $.ajax({
                url: aicr_image.ajax_url,
                type: 'POST',
                data: {
                    action: 'aicr_remove_images',
                    nonce: aicr_image.nonce,
                    post_id: postId
                },
                success: function(response) {
                    if (response.success) {
                        self.showResult('success', '이미지가 제거되었습니다.');
                        setTimeout(function() {
                            window.location.reload();
                        }, 1000);
                    } else {
                        self.showResult('error', response.data || aicr_image.strings.error);
                    }
                },
                error: function() {
                    self.showResult('error', aicr_image.strings.error);
                },
                complete: function() {
                    $button.prop('disabled', false).text('생성된 이미지 제거');
                }
            });
        },

        /**
         * Get post content from editor
         */
        getPostContent: function() {
            var content = '';

            // Try Gutenberg editor first
            if (typeof wp !== 'undefined' && wp.data && wp.data.select('core/editor')) {
                var editorContent = wp.data.select('core/editor').getEditedPostContent();
                if (editorContent) {
                    content = editorContent;
                }
            }

            // Fallback to Classic Editor
            if (!content) {
                if (typeof tinymce !== 'undefined' && tinymce.activeEditor) {
                    content = tinymce.activeEditor.getContent();
                } else {
                    content = $('#content').val() || '';
                }
            }

            return content;
        },

        /**
         * Show progress bar
         */
        showProgress: function(percent, text) {
            var $progress = $('#aicr-image-progress');
            $progress.show();
            $progress.find('.aicr-progress-fill').css('width', percent + '%');
            $progress.find('.aicr-progress-text').text(text);
        },

        /**
         * Hide progress bar
         */
        hideProgress: function() {
            $('#aicr-image-progress').hide();
        },

        /**
         * Simulate progress animation
         */
        simulateProgress: function() {
            var self = this;
            var progress = 0;
            var messages = [
                '콘텐츠 분석 중...',
                '주제 추출 중...',
                '프롬프트 생성 중...',
                'AI 이미지 생성 중...',
                '이미지 처리 중...'
            ];

            var interval = setInterval(function() {
                progress += Math.random() * 15;
                if (progress > 90) {
                    progress = 90;
                    clearInterval(interval);
                }

                var messageIndex = Math.min(Math.floor(progress / 20), messages.length - 1);
                self.showProgress(Math.floor(progress), messages[messageIndex]);
            }, 1500);

            // Store interval ID for cleanup
            this.progressInterval = interval;
        },

        /**
         * Show result message
         */
        showResult: function(type, message) {
            var $result = $('#aicr-image-result');
            $result.removeClass('success error').addClass(type);
            $result.html('<p>' + message + '</p>').show();

            // Clear progress interval
            if (this.progressInterval) {
                clearInterval(this.progressInterval);
            }
        },

        /**
         * Update status display
         */
        updateStatus: function(data) {
            var $status = $('.aicr-status');
            $status.removeClass('aicr-status-pending aicr-status-error').addClass('aicr-status-success');
            $status.html('<span class="dashicons dashicons-yes-alt"></span> ' + data.count + '개 이미지 생성됨');
        }
    };

    // Initialize on document ready
    $(document).ready(function() {
        ImageMetabox.init();
    });

})(jQuery);
