<?php
/**
 * Image Prompt Manager
 *
 * @package AIContentRewriter\Image
 */

namespace AIContentRewriter\Image;

/**
 * 이미지 프롬프트 관리 클래스 (싱글톤)
 *
 * 설정 페이지에서 프롬프트 템플릿을 직접 편집 가능
 */
class ImagePromptManager {
    /**
     * 싱글톤 인스턴스
     */
    private static ?ImagePromptManager $instance = null;

    /**
     * 프롬프트 옵션 키
     */
    private const OPTION_KEY = 'aicr_image_prompt';

    /**
     * 기본 이미지 생성 프롬프트
     */
    private const DEFAULT_PROMPT = <<<PROMPT
{{topic}}을 나타내는 {{style}} 스타일의 이미지.
블로그 게시글에 적합한, 전문적이고 깔끔한 디자인.
고품질, 선명함, 현대적인 느낌.
{{additional_instructions}}
PROMPT;

    /**
     * 생성자 (private for singleton)
     */
    private function __construct() {}

    /**
     * 복제 방지
     */
    private function __clone() {}

    /**
     * 싱글톤 인스턴스 반환
     */
    public static function get_instance(): ImagePromptManager {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * 저장된 프롬프트 반환 (없으면 기본값)
     */
    public function get_prompt(): string {
        $saved_prompt = get_option(self::OPTION_KEY);
        return $saved_prompt ?: self::DEFAULT_PROMPT;
    }

    /**
     * 프롬프트 저장
     */
    public function save_prompt(string $prompt): bool {
        return update_option(self::OPTION_KEY, $prompt);
    }

    /**
     * 기본 프롬프트 반환 (복원용)
     */
    public function get_default_prompt(): string {
        return self::DEFAULT_PROMPT;
    }

    /**
     * 변수 치환하여 최종 프롬프트 빌드
     *
     * @param array $variables 변수 배열
     * @return string 최종 프롬프트
     */
    public function build_prompt(array $variables): string {
        $template = $this->get_prompt();

        foreach ($variables as $key => $value) {
            $template = str_replace('{{' . $key . '}}', (string) $value, $template);
        }

        // 사용되지 않은 변수 제거
        $template = preg_replace('/\{\{[a-z_]+\}\}/i', '', $template);

        return trim($template);
    }

    /**
     * 스타일과 함께 전체 프롬프트 빌드
     *
     * @param string $topic 주제/섹션 내용
     * @param string $styleName 스타일 이름
     * @param string $additionalInstructions 추가 지시사항
     * @return string 최종 프롬프트
     */
    public function build_full_prompt(
        string $topic,
        string $styleName = '',
        string $additionalInstructions = ''
    ): string {
        $style = $this->get_style_by_name($styleName);

        $variables = [
            'topic' => $topic,
            'style' => $style['style_prompt'] ?? 'professional',
            'additional_instructions' => $additionalInstructions,
        ];

        $basePrompt = $this->build_prompt($variables);

        // 네거티브 프롬프트 추가 (있는 경우)
        if (!empty($style['negative_prompt'])) {
            $basePrompt .= "\n\nAvoid: " . $style['negative_prompt'];
        }

        return $basePrompt;
    }

    /**
     * 이름으로 스타일 조회
     */
    public function get_style_by_name(string $name): ?array {
        global $wpdb;

        if (empty($name)) {
            // 기본 스타일 반환
            return $this->get_default_style();
        }

        $table_name = $wpdb->prefix . 'aicr_image_styles';

        $style = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$table_name} WHERE name = %s LIMIT 1",
                $name
            ),
            ARRAY_A
        );

        return $style ?: $this->get_default_style();
    }

    /**
     * ID로 스타일 조회
     */
    public function get_style_by_id(int $id): ?array {
        global $wpdb;

        $table_name = $wpdb->prefix . 'aicr_image_styles';

        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$table_name} WHERE id = %d",
                $id
            ),
            ARRAY_A
        );
    }

    /**
     * 기본 스타일 조회
     */
    public function get_default_style(): ?array {
        global $wpdb;

        $table_name = $wpdb->prefix . 'aicr_image_styles';

        return $wpdb->get_row(
            "SELECT * FROM {$table_name} WHERE is_default = 1 LIMIT 1",
            ARRAY_A
        );
    }

    /**
     * 모든 스타일 조회
     */
    public function get_all_styles(): array {
        global $wpdb;

        $table_name = $wpdb->prefix . 'aicr_image_styles';

        $styles = $wpdb->get_results(
            "SELECT * FROM {$table_name} ORDER BY is_default DESC, name ASC"
        );

        return $styles ?: [];
    }

    /**
     * 스타일 저장
     */
    public function save_style(array $data): int|bool {
        global $wpdb;

        $table_name = $wpdb->prefix . 'aicr_image_styles';

        $style_data = [
            'name' => sanitize_text_field($data['name'] ?? ''),
            'description' => sanitize_textarea_field($data['description'] ?? ''),
            'style_prompt' => sanitize_textarea_field($data['style_prompt'] ?? ''),
            'negative_prompt' => sanitize_textarea_field($data['negative_prompt'] ?? ''),
            'aspect_ratio' => sanitize_text_field($data['aspect_ratio'] ?? '16:9'),
            'is_default' => !empty($data['is_default']) ? 1 : 0,
        ];

        // 기본 스타일로 설정 시 기존 기본 스타일 해제
        if ($style_data['is_default']) {
            $wpdb->update($table_name, ['is_default' => 0], ['is_default' => 1]);
        }

        if (!empty($data['id'])) {
            // 업데이트
            $wpdb->update($table_name, $style_data, ['id' => (int) $data['id']]);
            return (int) $data['id'];
        }

        // 새로 삽입
        $wpdb->insert($table_name, $style_data);
        return $wpdb->insert_id;
    }

    /**
     * 스타일 삭제
     */
    public function delete_style(int $id): bool {
        global $wpdb;

        $table_name = $wpdb->prefix . 'aicr_image_styles';

        // 기본 스타일은 삭제 불가
        $style = $this->get_style_by_id($id);
        if ($style && $style['is_default']) {
            return false;
        }

        return $wpdb->delete($table_name, ['id' => $id]) !== false;
    }

    /**
     * 사용 가능한 변수 목록
     */
    public function get_available_variables(): array {
        return [
            'topic' => __('섹션/단락의 주제', 'ai-content-rewriter'),
            'keywords' => __('추출된 키워드', 'ai-content-rewriter'),
            'style' => __('선택된 이미지 스타일', 'ai-content-rewriter'),
            'post_title' => __('게시글 제목', 'ai-content-rewriter'),
            'additional_instructions' => __('추가 지시사항', 'ai-content-rewriter'),
        ];
    }
}
