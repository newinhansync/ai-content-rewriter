<?php
/**
 * Image Generator
 *
 * @package AIContentRewriter\Image
 */

namespace AIContentRewriter\Image;

use AIContentRewriter\AI\GeminiAdapter;
use AIContentRewriter\AI\GeminiImageAdapter;

/**
 * 이미지 생성 통합 매니저
 *
 * 전체 흐름 조율 및 Featured Image 자동 설정
 */
class ImageGenerator {
    /**
     * 이미지 어댑터
     */
    private GeminiImageAdapter $imageAdapter;

    /**
     * 프롬프트 매니저
     */
    private ImagePromptManager $promptManager;

    /**
     * 콘텐츠 섹션 분할기
     */
    private ContentSectionizer $sectionizer;

    /**
     * 이미지 삽입기
     */
    private ImageInserter $inserter;

    /**
     * 생성된 첨부파일 ID (롤백용)
     */
    private array $generatedAttachments = [];

    /**
     * 생성자
     */
    public function __construct() {
        $this->imageAdapter = new GeminiImageAdapter();
        $this->promptManager = ImagePromptManager::get_instance();
        $this->sectionizer = new ContentSectionizer();
        $this->inserter = new ImageInserter();
    }

    /**
     * 게시글에 이미지 생성 및 삽입
     *
     * @param int $postId 게시글 ID
     * @param array $options 옵션 ['count', 'style', 'ratio', 'instructions']
     * @return array 생성된 이미지 정보 배열
     * @throws \Exception 에러 발생 시
     */
    public function generateForPost(int $postId, array $options = []): array {
        $this->generatedAttachments = [];

        $post = get_post($postId);
        if (!$post) {
            throw new \Exception(__('게시글을 찾을 수 없습니다.', 'ai-content-rewriter'));
        }

        // WordPress 포스트 락 확인 (관리자 환경에서만)
        if (function_exists('wp_check_post_lock')) {
            $lock = wp_check_post_lock($postId);
            if ($lock) {
                $user = get_userdata($lock);
                throw new \Exception(
                    sprintf(__('%s님이 이 게시글을 편집 중입니다. 나중에 다시 시도해주세요.', 'ai-content-rewriter'), $user->display_name)
                );
            }
        }

        // 처리 중 락 설정 (관리자 환경에서만)
        if (function_exists('wp_set_post_lock')) {
            wp_set_post_lock($postId);
        }

        try {
            $imageCount = $options['count'] ?? (int) get_option('aicr_image_default_count', 2);
            $style = $options['style'] ?? get_option('aicr_image_default_style', '일러스트레이션');
            $ratio = $options['ratio'] ?? get_option('aicr_image_default_ratio', '16:9');
            $instructions = $options['instructions'] ?? '';

            // 이미지 수 제한
            $imageCount = max(1, min(5, $imageCount));

            // 1. 콘텐츠를 섹션으로 분할
            $sections = $this->sectionizer->sectionize($post->post_content, $imageCount);
            $insertionPoints = $this->sectionizer->getInsertionPoints($post->post_content, $imageCount);

            // 실제 섹션 수에 맞게 조정
            $imageCount = min($imageCount, count($sections));

            // 2. 각 섹션에 대해 이미지 생성
            $generatedImages = [];

            for ($index = 0; $index < $imageCount; $index++) {
                $section = $sections[$index] ?? null;
                if (!$section) {
                    continue;
                }

                // 프롬프트 빌드
                $prompt = $this->promptManager->build_full_prompt(
                    $section['topic'],
                    $style,
                    $instructions
                );

                // 이미지 생성
                $response = $this->imageAdapter->generate($prompt, [
                    'aspect_ratio' => $ratio,
                ]);

                if (!$response->isSuccess()) {
                    $this->logFailure($postId, $response->getErrorMessage(), $index);
                    continue;
                }

                // 미디어 라이브러리에 저장
                $attachmentId = $this->saveToMediaLibrary(
                    $response->getBase64(),
                    $postId,
                    $section['topic']
                );

                $this->generatedAttachments[] = $attachmentId;

                $imageData = [
                    'attachment_id' => $attachmentId,
                    'alt' => $section['topic'],
                    'caption' => '',
                    'section_index' => $index,
                ];

                $generatedImages[] = $imageData;

                // 이미지 히스토리 기록
                $this->logImageHistory($postId, $attachmentId, $prompt, $style, $ratio, $index, $response->getResponseTime());

                // 3. 첫 번째 이미지를 Featured Image로 설정
                if ($index === 0 && get_option('aicr_image_auto_featured', true)) {
                    $this->setFeaturedImage($postId, $attachmentId);
                }
            }

            if (empty($generatedImages)) {
                throw new \Exception(__('이미지를 생성하지 못했습니다.', 'ai-content-rewriter'));
            }

            // 4. 콘텐츠에 이미지 삽입
            $newContent = $this->inserter->insert(
                $post->post_content,
                $generatedImages,
                $insertionPoints
            );

            // 5. 게시글 업데이트
            $result = wp_update_post([
                'ID' => $postId,
                'post_content' => $newContent,
            ]);

            if (is_wp_error($result)) {
                throw new \Exception($result->get_error_message());
            }

            // 6. 메타데이터 저장
            update_post_meta($postId, 'aicr_images_generated', true);
            update_post_meta($postId, 'aicr_images_generated_at', current_time('mysql'));
            update_post_meta($postId, 'aicr_images_count', count($generatedImages));

            return $generatedImages;

        } catch (\Exception $e) {
            // 롤백: 생성된 첨부파일 삭제
            foreach ($this->generatedAttachments as $attachmentId) {
                wp_delete_attachment($attachmentId, true);
            }
            throw $e;

        } finally {
            // 락 해제
            delete_post_meta($postId, '_edit_lock');
        }
    }

    /**
     * Base64 이미지를 미디어 라이브러리에 저장
     */
    private function saveToMediaLibrary(string $base64, int $postId, string $title): int {
        $uploadDir = wp_upload_dir();
        $filename = 'aicr-image-' . $postId . '-' . time() . '-' . wp_rand(100, 999) . '.png';
        $filePath = $uploadDir['path'] . '/' . $filename;

        // Base64 디코딩 및 파일 저장
        $imageData = base64_decode($base64);
        if ($imageData === false) {
            throw new \Exception(__('이미지 데이터 디코딩 실패', 'ai-content-rewriter'));
        }

        $result = file_put_contents($filePath, $imageData);
        if ($result === false) {
            throw new \Exception(__('이미지 파일 저장 실패', 'ai-content-rewriter'));
        }

        // 메모리 해제
        unset($imageData);

        // 미디어 라이브러리에 등록
        $fileType = wp_check_filetype($filename, null);

        $attachment = [
            'post_mime_type' => $fileType['type'] ?? 'image/png',
            'post_title' => sanitize_file_name($title),
            'post_content' => '',
            'post_status' => 'inherit',
        ];

        $attachmentId = wp_insert_attachment($attachment, $filePath, $postId);

        if (is_wp_error($attachmentId)) {
            @unlink($filePath);
            throw new \Exception($attachmentId->get_error_message());
        }

        // 메타데이터 생성
        require_once ABSPATH . 'wp-admin/includes/image.php';
        $metadata = wp_generate_attachment_metadata($attachmentId, $filePath);
        wp_update_attachment_metadata($attachmentId, $metadata);

        // Alt 텍스트 설정
        update_post_meta($attachmentId, '_wp_attachment_image_alt', $title);

        return $attachmentId;
    }

    /**
     * Featured Image (대표 이미지) 설정
     */
    private function setFeaturedImage(int $postId, int $attachmentId): void {
        set_post_thumbnail($postId, $attachmentId);
    }

    /**
     * 이미지 생성 이력 기록
     */
    private function logImageHistory(
        int $postId,
        int $attachmentId,
        string $prompt,
        string $style,
        string $ratio,
        int $sectionIndex,
        float $generationTime
    ): void {
        global $wpdb;

        $tableName = $wpdb->prefix . 'aicr_image_history';

        $wpdb->insert($tableName, [
            'post_id' => $postId,
            'attachment_id' => $attachmentId,
            'prompt' => $prompt,
            'style' => $style,
            'aspect_ratio' => $ratio,
            'section_index' => $sectionIndex,
            'generation_time' => $generationTime,
            'status' => 'success',
            'created_at' => current_time('mysql'),
        ]);
    }

    /**
     * 실패 기록
     */
    private function logFailure(int $postId, string $error, int $sectionIndex): void {
        global $wpdb;

        $tableName = $wpdb->prefix . 'aicr_image_history';

        $wpdb->insert($tableName, [
            'post_id' => $postId,
            'attachment_id' => null,
            'prompt' => '',
            'section_index' => $sectionIndex,
            'status' => 'failed',
            'error_message' => $error,
            'created_at' => current_time('mysql'),
        ]);
    }

    /**
     * 게시글의 AI 생성 이미지 삭제
     */
    public function removeImagesFromPost(int $postId): bool {
        $post = get_post($postId);
        if (!$post) {
            return false;
        }

        // 콘텐츠에서 이미지 제거
        $newContent = $this->inserter->removeGeneratedImages($post->post_content);

        // 게시글 업데이트
        wp_update_post([
            'ID' => $postId,
            'post_content' => $newContent,
        ]);

        // 메타데이터 제거
        delete_post_meta($postId, 'aicr_images_generated');
        delete_post_meta($postId, 'aicr_images_generated_at');
        delete_post_meta($postId, 'aicr_images_count');

        return true;
    }

    /**
     * 게시글에 이미지가 필요한지 확인
     */
    public function needsImages(int $postId): bool {
        // 이미 이미지 생성됨
        if (get_post_meta($postId, 'aicr_images_generated', true)) {
            return false;
        }

        // Featured Image 이미 있음
        if (has_post_thumbnail($postId) && get_option('aicr_image_skip_with_thumbnail', true)) {
            return false;
        }

        // 콘텐츠에 이미지 태그 이미 있음
        $content = get_post_field('post_content', $postId);
        if ($this->inserter->hasImages($content) && get_option('aicr_image_skip_with_images', true)) {
            return false;
        }

        return true;
    }

    /**
     * 이미지 생성 상태 조회
     */
    public function getGenerationStatus(int $postId): array {
        $generated = get_post_meta($postId, 'aicr_images_generated', true);
        $generatedAt = get_post_meta($postId, 'aicr_images_generated_at', true);
        $count = get_post_meta($postId, 'aicr_images_count', true);

        return [
            'generated' => (bool) $generated,
            'generated_at' => $generatedAt ?: null,
            'count' => (int) $count,
            'has_featured' => has_post_thumbnail($postId),
        ];
    }
}
